"use client";

import { MediaFallback } from "@/components/media-fallback";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, HeartIcon, StarIcon } from "@/components/icons";
import { ContentPage } from "@/components/public-pages";
import { properties } from "@/lib/data";
import { Price } from "@/components/price";
import { useCurrency } from "@/components/currency-provider";

export function DealsPage() {
  const deals = [{ title: "Three nights, one perfect island", label: "Sample offer", copy: "A calmer kind of package for travellers who want more reef time and less planning.", image: properties[0].image }, { title: "Stay local, see more", label: "Guesthouse edit", copy: "Pair a local-island base with a guided reef day and a sunset dhoni.", image: properties[3].image }, { title: "A little longer in paradise", label: "Seasonal idea", copy: "Build seven days around two islands and let the transfer become part of the story.", image: properties[2].image }];
  return <><section className="page-hero"><div className="page-wrap page-heading"><span className="eyebrow">CURRENTLY CURATING</span><h1>Good reasons to stay a little longer.</h1><p>Sample offers today, partner-funded deals tomorrow. Every promotion will be clearly labelled and confirmed before you book.</p></div></section><main className="page-main"><div className="page-wrap deal-grid">{deals.map((deal) => <article className="deal-card" style={{ backgroundImage: `linear-gradient(180deg, rgba(5,35,40,.06), rgba(5,35,40,.8)), url(${deal.image})` }} key={deal.title}><span className="deal-label">{deal.label}</span><div><h2>{deal.title}</h2><p>{deal.copy}</p><Link href="/plan-your-trip" className="deal-link">Build this trip <ArrowUpRight size={13} /></Link></div></article>)}</div><MediaFallback /></main></>;
}

export function ComparePage() {
  const [selected, setSelected] = useState(properties.slice(0, 3).map((property) => property.slug));
  const choices = properties.filter((property) => selected.includes(property.slug));
  const { formatPrice } = useCurrency();
  return <><section className="page-hero"><div className="page-wrap page-heading"><span className="eyebrow">COMPARE STAYS</span><h1>See what changes between islands.</h1><p>Compare up to four stays by price, transfer, style and rating. Sample inventory is intentionally labelled.</p></div></section><main className="page-main"><div className="page-wrap"><div className="compare-picker">{properties.map((property) => <button key={property.slug} className={`filter-chip ${selected.includes(property.slug) ? "active" : ""}`} onClick={() => setSelected((current) => current.includes(property.slug) ? current.filter((slug) => slug !== property.slug) : current.length < 4 ? [...current, property.slug] : current)}>{property.name}</button>)}</div>{choices.length ? <div className="compare-table"><div className="compare-head"><div>Compare</div>{choices.map((property) => <div key={property.slug}><span className="compare-thumb" style={{ backgroundImage: `url(${property.image})` }} /><strong>{property.name}</strong><span>{property.location}</span></div>)}</div>{[["From / night", ...choices.map((item) => formatPrice(item.price))], ["Rating", ...choices.map((item) => `${item.rating} / 5`)], ["Transfer", ...choices.map((item) => item.transfer)], ["Best for", ...choices.map((item) => item.tags.slice(0, 2).join(" · "))], ["Booking mode", ...choices.map(() => "Request to book")]].map((row) => <div className="compare-row" key={row[0]}>{row.map((cell, index) => index === 0 ? <strong key={`${row[0]}-${index}`}>{cell}</strong> : <span key={`${row[0]}-${index}`}>{cell}</span>)}</div>)}</div> : <div className="empty-state">Choose a stay above to compare it.</div>} </div><MediaFallback /></main></>;
}

export function WishlistPage() {
  const [saved, setSaved] = useState(properties.slice(0, 2));
  return <><section className="page-hero"><div className="page-wrap page-heading"><span className="eyebrow">YOUR WISHLIST</span><h1>Keep the places you keep thinking about.</h1><p>This sample wishlist is kept only during this visit. Changes reset when you reload; account sync is not available.</p></div></section><main className="page-main"><div className="page-wrap">{saved.length ? <div className="directory-grid">{saved.map((property) => <div key={property.slug} className="wishlist-wrap"><PropertySaved property={property} onRemove={() => setSaved((current) => current.filter((item) => item.slug !== property.slug))} /></div>)}</div> : <div className="empty-state">Your wishlist is waiting for a few island ideas. <Link className="text-link" href="/stay">Browse stays <ArrowRight size={13} /></Link></div>}</div><MediaFallback /></main></>;
}
function PropertySaved({ property, onRemove }: { property: typeof properties[number]; onRemove: () => void }) { return <article className="stay-card"><div className="stay-image" style={{ "--card-image": `url(${property.image})` } as React.CSSProperties}><span className="stay-badge">Saved</span><button className="image-heart" type="button" onClick={onRemove} aria-label="Remove from wishlist"><HeartIcon filled /></button></div><div className="stay-body"><div className="stay-meta"><span>{property.location}</span><span><StarIcon size={11} /> {property.rating}</span></div><h3>{property.name}</h3><p>{property.description}</p><div className="stay-footer"><Link href={`/stay/${property.slug}`}>View stay <ArrowUpRight size={13} /></Link><span>From <Price usd={property.price} /></span></div></div></article>; }

export function AccountPage() {
  return <ContentPage eyebrow="YOUR ACCOUNT" title="Your trip, in one place." description="Explore stays, compare sample inventory and choose your preferred display currency."><div className="account-grid"><div className="detail-card"><span className="eyebrow">ACCOUNT PREVIEW</span><h2>Sign-in is not available yet.</h2><p>This MVP does not authenticate accounts or sync bookings and favourites. No credentials are collected here and this page does not grant account access.</p><button className="button button-teal full-button" type="button" disabled style={{ marginTop: 12 }}>Sign-in unavailable</button></div><div className="detail-card"><span className="eyebrow">Keep exploring</span><h2>Plan your island discoveries.</h2><p>Browse the destination guides and compare stays. Booking and payment occur only on an approved partner website when a partner link is available.</p><Link className="button button-sun" href="/plan-your-trip">Plan a trip <ArrowRight size={14} /></Link></div></div></ContentPage>;
}
